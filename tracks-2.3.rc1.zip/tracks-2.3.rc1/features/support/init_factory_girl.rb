# require 'factory_girl'
# Dir.glob(File.join(File.dirname(__FILE__), 'factories/*.rb')).each {|f| require f }