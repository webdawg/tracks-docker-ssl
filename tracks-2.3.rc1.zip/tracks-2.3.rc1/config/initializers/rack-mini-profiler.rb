# Have Mini Profiler show up on the right
Rack::MiniProfiler.config.position = 'right' if defined?(Rack::MiniProfiler)